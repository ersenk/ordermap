import { Injectable } from '@angular/core';
import { ConfigService } from '../config/config.service';
import { Storage } from '@ionic/storage';
import { HttpClient } from '@angular/common/http';
import { LoadingService } from '../loading/loading.service';
import { Platform, ToastController, Events, AlertController, NavController } from '@ionic/angular';
import { OneSignal } from '@ionic-native/onesignal/ngx';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { AppVersion } from '@ionic-native/app-version/ngx';
import { FCM } from '@ionic-native/fcm/ngx';
import { Device } from '@ionic-native/device/ngx';
import { BehaviorSubject } from 'rxjs';
@Injectable()
export class SharedDataService {
  public osimdiBranches = [];
  public myDistanceToClosestOsimdiBranch = '';
  public myLocation: any = '';
  public branchId: number = 1; //default merkez şube
  public shippingMethod: number = 1; //1 kargo, 2 kurye
  public shippingCost = 0;
  public shoppingBagCost = this.config.bagPrices.shopping_bag;
  public banners = [];
  public tab1 = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1];
  public tab2 = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1];
  public tab3 = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1];
  public campaigns = [];
  public flashSaleProducts = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1];
  public allCategories: any = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1];
  public categories: any = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1];
  public subCategories: any = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1];
  public customerData: { [k: string]: any } = {};
  public recentViewedProducts = new Array();
  public cartProducts = new Array();
  public privacyPolicy = '';
  public termServices = '';
  public refundPolicy = '';
  public aboutUs = '';
  public mesafeliSatisSozlesmesi = '';
  public bilgilendirmeFormu = '';
  public cartquantity = 0;
  public wishList = new Array();
  public tempdata: { [k: string]: any } = {};
  public dir = 'ltr';
  public selectedFooterPage = 'HomePage';
  public currentOpenedModel: any = null;
  public isCartPopUpOpen = new BehaviorSubject(false);
  public isLocationTurnedOn = new BehaviorSubject(false);
  public branchIdHasChanged = new BehaviorSubject(false);
  public customerWaitingForDelivery = new BehaviorSubject(false);
  public customerChangedShoppingBag = new BehaviorSubject(false);
  public customersDefaultAddress = [];
  public orderDetails = {
    delivery_address_id: '',
    delivery_district_name: '',
    delivery_street_name: '',
    delivery_open_address: '',
    delivery_city_name: '',
    delivery_city_id: '',
    delivery_zone_name: '',
    delivery_zone_id: '',
    delivery_contact_telephone: '',
    payment_method: '',
    comments: '',
    delivery_hours: '',
    order_platform: 0,
    shipping_cost: 0
  };
  public billingAddress = {
    name: '',
    tax_number: '',
    taxt_city: '',
    open_address: '',
  }
  public orderCustomerSetings = {
    bag_option: 1,
    branch_id: '',
    ring_bell: 0,
    no_touch_delivery: 0,
  };
  public translationListArray = [{ 'Recently Viewed': 'Son Ziyaret Edilen', 'Remove': 'Kaldır', 'REMOVE': 'KALDIR', 'Added': 'Sepette' }];
  public singleProductPageData = [];
  public singlePostData: any;
  myOrderDetialPageData: any;
  public categoryBucket = [];
  constructor(
    public config: ConfigService,
    public httpClient: HttpClient,
    public storage: Storage,
    public loading: LoadingService,
    public events: Events,
    public platform: Platform,
    public device: Device,
    public fcm: FCM,
    public alertCtrl: AlertController,
    public appVersion: AppVersion,
    public oneSignal: OneSignal,
    private toastCtrl: ToastController,
    public splashScreen: SplashScreen,
    public alertController: AlertController,
    private navCtrl: NavController,
  ) {
    this.platform.ready().then(() => {
      this.config.getHttp('applabels3?lang=' + this.config.langId).then((data: any) => {
        this.translationListArray = data;
      });
    });
    events.subscribe('settingsLoaded', () => {
      this.onStart();
    });

    // getting recent viewed items from local storage
    storage.get('customerData').then((val) => {
      if (val != null || val != undefined) { this.customerData = val; }
    });
    // getting recent viewed items from local storage
    storage.get('recentViewedProducts').then((val) => {
      if (val != null) { this.recentViewedProducts = val; }
    });
    if (this.platform.is('cordova')) {
    }
    if (this.platform.is('desktop')) {
      this.orderDetails.order_platform = 1;
    }
    if (this.platform.is('android')) {
      this.orderDetails.order_platform = 2;
    }
    if (this.platform.is('ios')) {
      this.orderDetails.order_platform = 3;
    }
    if (this.platform.is('mobileweb')) {
      this.orderDetails.order_platform = 4;
    }
    // getting recent viewed items from local storage
    storage.get('cartProducts').then((val) => {
      if (val != null) { this.cartProducts = val; }
      this.cartTotalItems();
    });
    this.branchIdHasChanged.subscribe(branch => {
      if (branch) {
        this.onStart();
      }
    });
  }
  public splashScreenHide = false;
  hideSplashScreen() {
    if (this.platform.is('cordova')) {
      if (!this.splashScreenHide) { this.splashScreen.hide(); this.splashScreenHide = true; }
    }
  }
  onStart() {
    // getting all branches
    this.config.postHttp('branches', {}).then((data: any) => {
      this.osimdiBranches = data.data;
    });
    // getting all banners
    this.config.getHttp('getbanners').then((data: any) => {
      this.banners = data.data;
    });
    this.defaultAddress();
    const dat = { customers_id: this.customerData.customers_id };
    this.config.postHttp('getalladdress', dat).then((data: any) => {
      if (data.success == 1) {
        this.customersDefaultAddress = [];
        data.data.forEach(element => {
          if (element.is_default == 1) {
            this.customersDefaultAddress.push(element);
          }
        });
      }
    });

    let data: { [k: string]: any } = {};
    if (this.customerData.customers_id != null) {
      data.customers_id = this.customerData.customers_id;
    }
    data.page_number = 0;
    data.language_id = this.config.langId;
    data.currency_code = this.config.currecnyCode;
    data.branch_id = this.branchId;
    data.type = 'special';
    this.config.postHttp('getalltheproducts', data).then((data: any) => {
      this.campaigns = data.campaigns;
    });

    this.config.postHttp('allcategories', data).then((data: any) => {
      if (this.allCategories[0] == 1) {
        this.allCategories = [];
        this.categories = [];
        this.subCategories = [];
      }
      this.allCategories = [];
      this.categories = [];
      this.subCategories = [];

      for (let value of data.data) {
        value.id = value.id;
        value.name = value.name;
        this.allCategories.push(value);
        if (value.parent_id == 0) {
          this.categories.push(value);
        } else {
          this.subCategories.push(value);
        }
      }

      for (let index = 0; index < this.categories.length; index++) {
        let subCateBucket = {
          category: '',
          subcategory: []
        };
        subCateBucket.category = this.categories[index];
        for (let i = 0; i < this.subCategories.length; i++) {
          if (this.subCategories[i].parent_id === this.categories[index].id) {
            subCateBucket.subcategory.push(this.subCategories[i]);
          }
        }
        this.categoryBucket.push(subCateBucket);
      }
    });
    // getting allpages from the server
    this.config.postHttp('getallpages', { language_id: this.config.langId, currency_code: this.config.currecnyCode }).then((data: any) => {
      if (data.success == 1) {
        let pages = data.pages_data;
        for (let value of pages) {
          if (value.slug == 'privacy-policy') { this.privacyPolicy = value.description; }
          if (value.slug == 'term-services') { this.termServices = value.description; }
          if (value.slug == 'refund-policy') { this.refundPolicy = value.description; }
          if (value.slug == 'about-us') { this.aboutUs = value.description; }
          if (value.slug == 'mesefeli-satis-sozlesmesi') { this.mesafeliSatisSozlesmesi = value.description; }
          if (value.slug == 'bilgilendirme-formu') { this.bilgilendirmeFormu = value.description; }
        }
      }
    });
    this.getPushNotifications();
  }
  defaultAddress() {
    const dat = { customers_id: this.customerData.customers_id };
    this.config.postHttp('getalladdress', dat).then((data: any) => {
      if (data.success == 1) {
        this.customersDefaultAddress = [];
        data.data.forEach(element => {
          if (element.is_default == 1) {
            this.customersDefaultAddress.push(element);
          }
        });
      }
    });
  }
  async getBranches() {
    let branches;
    this.config.postHttp('branches', {}).then(async (data: any) => {
      this.osimdiBranches = branches = data.data;
      return await branches;
    });
    return await branches;
  }
  // adding into recent array products
  addToRecent(p) {
    let found = false;
    for (let value of this.recentViewedProducts) {
      if (value.products_id == p.products_id) { found = true; }
    }
    if (found == false) {
      this.recentViewedProducts.push(p);
      this.storage.set('recentViewedProducts', this.recentViewedProducts);
    }
  }
  // removing from recent array products
  removeRecent(p) {
    this.recentViewedProducts.forEach((value, index) => {
      if (value.products_id == p.products_id) {
        this.recentViewedProducts.splice(index, 1);
        this.storage.set('recentViewedProducts', this.recentViewedProducts);
      }
    });
    this.events.publish('recentDeleted');
  }
  // adding into cart array products
  addToCart(product, attArray) {
    let attributesArray = attArray;
    if (attArray.length == 0 || attArray == null) {
      attributesArray = [];
      if (product.attributes != undefined) {
        product.attributes.forEach((value, index) => {
          let att = {
            products_options_id: value.option.id,
            products_options: value.option.name,
            products_options_values_id: value.values[0].id,
            options_values_price: value.values[0].price,
            price_prefix: value.values[0].price_prefix,
            products_options_values: value.values[0].value,
            name: value.values[0].value + ' ' + value.values[0].price_prefix + value.values[0].price + ' ' + this.config.currency
          };
          attributesArray.push(att);
        });
      }
    }
    //  if(checkDublicateService(product.products_id,$rootScope.cartProducts)==false){

    let pprice = product.products_price;
    let discounted_price = '';
    let on_sale = false;
    let notdiscounted_price = '';
    if (product.discount_price != null) {
      pprice = product.discount_price;
      on_sale = true;
      notdiscounted_price = product.products_price;
    }
    if (product.flash_price != null) {
      pprice = product.flash_price;
    }
    let finalPrice = this.calculateFinalPriceService(attributesArray) + parseFloat(pprice);
    let obj = {
      cart_id: product.products_id + this.cartProducts.length,
      products_id: product.products_id,
      manufacture: product.manufacturers_name,
      customers_basket_quantity: Number(product.products_min_order),
      final_price: finalPrice,
      model: product.products_model,
      categories: product.categories,
      weight: product.products_weight,
      on_sale: on_sale,
      unit: product.products_weight_unit,
      image: product.image_thumb,
      attributes: attributesArray,
      products_name: product.products_name,
      price: pprice,
      notdiscounted_price: notdiscounted_price,
      subtotal: finalPrice,
      total: finalPrice,
      products_min_order: product.products_min_order,
      products_max_stock: product.products_max_stock
    };
    if (this.isInCart(product)) {
      return;
    } else {
      this.cartProducts.push(obj);
      this.storage.set('cartProducts', this.cartProducts);
      this.cartTotalItems();
    }
  }

  isInCart(product) {
    var found = false;
    for (let value of this.cartProducts) {
      if (value.products_id == product.products_id) {
        found = true;
      }
    }
    if (found == true) {
      return true;
    } else {
      return false;
    }
  }

  removeCart(p) {
    this.cartProducts.forEach((value, index) => {
      if (value.cart_id == p) {
        this.cartProducts.splice(index, 1);
        this.storage.set('cartProducts', this.cartProducts);
      }
    });
    this.cartTotalItems();
  }
  emptyCart() {
    this.cartProducts = [];
    this.storage.set('cartProducts', this.cartProducts);
    this.cartTotalItems();
  }
  emptyRecentViewed() {
    this.recentViewedProducts = [];
    this.storage.set('recentViewedProducts', this.recentViewedProducts);
  }
  calculateFinalPriceService(attArray) {
    let total = 0;
    attArray.forEach((value, index) => {
      let attPrice = parseFloat(value.options_values_price);
      if (value.price_prefix == '+') {
        total += attPrice;
      }
      else {
        total -= attPrice;
      }
    });
    return total;
  }

  // Function calcualte the total items of cart
  cartTotalItems = function () {
    this.events.publish('cartChange');
    let total = 0;
    for (let value of this.cartProducts) {
      total += value.customers_basket_quantity;
    }
    this.cartquantity = total;
    return total;
  };

  removeWishList(p) {
    this.loading.show();
    let data: { [k: string]: any } = {};
    data.liked_customers_id = this.customerData.customers_id;
    data.liked_products_id = p.products_id;
    this.config.postHttp('unlikeproduct', data).then((data: any) => {
      this.loading.hide();
      if (data.success == 1) {
        this.events.publish('wishListUpdate', p.products_id, 0);
        p.isLiked = 0;
        this.wishList.forEach((value, index) => {
          if (value.products_id == p.products_id) { this.wishList.splice(index, 1); }
        });
      }
      if (data.success == 0) {

      }
    });
  }
  addWishList(p) {
    this.loading.show();
    let data: { [k: string]: any } = {};
    data.liked_customers_id = this.customerData.customers_id;
    data.liked_products_id = p.products_id;
    this.config.postHttp('likeproduct', data).then((data: any) => {
      this.loading.hide();
      if (data.success == 1) {
        this.events.publish('wishListUpdate', p.products_id, 1);
        p.isLiked = 1;
      }

      if (data.success == 0) { }
    });
  }
  login(data) {
    this.customerData = data;
    this.customerData.customers_telephone = data.customers_telephone;
    this.customerData.phone = data.phone;
    this.customerData.customers_id = data.customers_id;
    this.customerData.customers_firstname = data.customers_firstname;
    this.customerData.customers_lastname = data.customers_lastname;
    this.customerData.phone = data.customers_telephone;
    this.customerData.avatar = data.customers_picture;
    this.customerData.image_id = data.image_id;
    this.customerData.customers_dob = data.customers_dob;
    this.customerData.customers_type = data.customers_type;
    this.storage.set('customerData', this.customerData);
    this.subscribePush();
    this.onStart();
  }
  logOut() {
    this.loading.autoHide(500);
    this.customerData = {};
    this.storage.set('customerData', this.customerData);
    this.onStart();
  }


  // ============================================================================================
  // getting token and passing to server

  subscribePush() {
    if (this.platform.is('cordova')) {
      if (this.config.notificationType == 'fcm') {
        try {
          this.fcm.subscribeToTopic('marketing');
          this.fcm.getToken().then(token => {
            this.registerDevice(token);
          });

          this.fcm.onNotification().subscribe(data => {
            if (data.wasTapped) {
            } else {
            }
          });

          this.fcm.onTokenRefresh().subscribe(token => {
            this.registerDevice(token);
          });

        } catch (error) {

        }
      }
      else if (this.config.notificationType == 'onesignal') {

        this.oneSignal.startInit(this.config.onesignalAppId, this.config.onesignalSenderId);
        this.oneSignal.inFocusDisplaying(this.oneSignal.OSInFocusDisplayOption.None);
        this.oneSignal.handleNotificationReceived().subscribe(data => {
          let additionalData = data.payload.additionalData;
          if (additionalData.app_url && additionalData.app_url) {
            this.navCtrl.navigateForward(additionalData.app_url);
          }
        });

        this.oneSignal.handleNotificationOpened().subscribe(data => { });
        this.oneSignal.endInit();
        this.oneSignal.getIds().then((data) => {
          this.registerDevice(data.userId);
        });
      }
    }
  }

  getPushNotifications() {
    if (this.platform.is('cordova')) {
      if (this.config.notificationType == 'fcm') {
        try {
          this.fcm.subscribeToTopic('marketing');

          this.fcm.getToken().then(token => {
            this.registerDevice(token);
          });

          this.fcm.onNotification().subscribe(data => {
            if (data.wasTapped) {
            } else {
            }
          });

          this.fcm.onTokenRefresh().subscribe(token => {
            this.registerDevice(token);
          });

        } catch (error) {

        }
      }
      else if (this.config.notificationType == 'onesignal') {

        this.oneSignal.startInit(this.config.onesignalAppId, this.config.onesignalSenderId);
        this.oneSignal.inFocusDisplaying(this.oneSignal.OSInFocusDisplayOption.None);

        this.oneSignal.handleNotificationReceived().subscribe(data => {
          let additionalData = data.payload.additionalData;
          if (additionalData.app_url && additionalData.app_url) {
            this.navCtrl.navigateForward(additionalData.app_url);
          }
        });

        this.oneSignal.handleNotificationOpened().subscribe(data => { });
        this.oneSignal.endInit();
      }
    }
  }
  registerDevice(registrationId) {

    let data: { [k: string]: any } = {};
    if (this.customerData.customers_id == null) {
      data.customers_id = null;
    }
    else {
      data.customers_id = this.customerData.customers_id;
    }
    let deviceInfo = this.device;
    data.device_model = deviceInfo.model;
    data.device_type = deviceInfo.platform;
    data.device_id = registrationId;
    data.device_os = deviceInfo.version;
    data.manufacturer = deviceInfo.manufacturer;
    data.ram = '2gb';
    data.processor = 'mediatek';
    data.location = 'empty';
    this.config.postHttp('registerdevices', data).then(data => {
    });
  }

  showAd() {
    this.events.publish('showAd');
  }

  toast(msg) {
    this.translateString(msg).then(async (res: string) => {
      const toast = await this.toastCtrl.create({
        message: res,
        duration: 3500,
        position: 'bottom'
      });
      toast.present();
    });
  }
  toastMiddle(msg) {

    this.translateString(msg).then(async (res: string) => {
      let toast = await this.toastCtrl.create({
        message: res,
        duration: 3500,
        position: 'middle'
      });

      toast.present();
    });
  }

  toastWithCloseButton(msg) {

    this.translateString(msg).then(async (res: string) => {
      let toast = await this.toastCtrl.create({
        message: res,
        showCloseButton: true,
        position: 'middle',
        closeButtonText: 'X'
      });

      toast.present();
    });
  }


  // categories page

  getCategoriesPageItems(parent) {
    let c = [];
    if (parent == undefined) {
      c = this.categories;
    }
    else {
      for (let v of this.allCategories) {
        if (v.parent == parent) {
          c.push(v);
        }
      }
    }
    return c;
  }

  // translation services
  translateString(value) {
    return new Promise(resolve => {
      let v = this.translationListArray[value];
      if (v == undefined) {
        v = value;
      }
      resolve(v);
    });
  }
  translateArray(value) {
    return new Promise(resolve => {
      let tempArray = [];
      value.forEach(element => {
        if (this.translationListArray[element] != undefined) {
          tempArray[element] = this.translationListArray[element];
        }
        else {
          tempArray[element] = element;
        }
      });
      resolve(tempArray);
    });
  }
  showAlert(text) {
    this.translateArray([text, 'ok', 'Alert']).then(async (res) => {
      const alert = await this.alertCtrl.create({
        header: res['Alert'],
        message: res[text],
        buttons: [res['ok']]
      });
      await alert.present();
    });
  }

  showAlertWithTitle(text, title) {
    this.translateArray([text, 'ok', title]).then(async (res) => {
      let alert = await this.alertCtrl.create({
        header: res[title],
        message: res[text],
        buttons: [res['ok']]
      });
      await alert.present();
    });
  }
  isCartPopUpOpened() {
    return this.isCartPopUpOpen.value;
  }
  getNameFirstLetter() {

  }
  async presentAlert(meesage, buttonaction) {
    const alert = await this.alertController.create({
      header: 'Alert',
      subHeader: 'Subtitle',
      message: meesage,
      buttons: [
        {
          text: `Action: ${buttonaction}`,
          handler: () => {
            // E.g: Navigate to a specific screen
          }
        }
      ]
    });

    await alert.present();
  }

}
