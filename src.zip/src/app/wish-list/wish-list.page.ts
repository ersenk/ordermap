import { Component, OnInit, ViewChild } from '@angular/core';
import { NavController, IonInfiniteScroll } from '@ionic/angular';
import { ConfigService } from 'src/providers/config/config.service';
import { SharedDataService } from 'src/providers/shared-data/shared-data.service';
import { Storage } from '@ionic/storage';
import { LoadingService } from '../../providers/loading/loading.service';

@Component({
  selector: 'app-wish-list',
  templateUrl: './wish-list.page.html',
  styleUrls: ['./wish-list.page.scss'],
})
export class WishListPage implements OnInit {
  @ViewChild(IonInfiniteScroll, { static: false }) infinite: IonInfiniteScroll;
  page = 0;
  httpRunning = false;
  hasMoreProductsOnList: any = true;
  shopListIndex: number = 0;
  interval;
  constructor(
    public navCtrl: NavController,
    public config: ConfigService,
    public shared: SharedDataService,
    public storage: Storage,
    public loading: LoadingService
    ) {}

   getProducts() {
    this.httpRunning = true;
    var dat: { [k: string]: any } = {};
    if (this.shared.customerData.customers_id != null){
      dat.customers_id = this.shared.customerData.customers_id;
    } else {
      return;
    }
    dat.page_number = this.page;
    dat.type = 'wishlist';
    dat.language_id = this.config.langId;
    dat.currency_code = this.config.currecnyCode;
    this.config.postHttp('getallproducts', dat).then((data: any) => {
      this.infinite.complete();
      this.httpRunning = false;
      if (data.success == 1) {
        this.page++;
        var prod = data.product_data;
        for (let value of prod) {
          this.shared.wishList.push(value);
        }
      }
      if (data.success == 0) { 
        this.infinite.disabled = true;
      }
    });
  }
  ngOnInit() {
    this.getProducts();
    this.shared.wishList = [];
    this.page = 0;
  }
  openProductsPage() {
    this.navCtrl.navigateForward("/products/0/0/top seller");
  }
  async addAllProductsToCart() {
    let index = 0;
    this.loading.show();
    do {
      this.hasMoreProductsOnList = await this.fillShopList();
      index++;
    } while (this.hasMoreProductsOnList == true);
    this.loading.hide();
  }
  async fillShopList(): Promise<boolean> {
    this.httpRunning = true;
    let hasMoreProduct: boolean = true;
    let dat: { [k: string]: any } = {};
    if (this.shared.customerData.customers_id != null) {
      dat.customers_id = this.shared.customerData.customers_id;
    } else {
      return;
    }
    dat.page_number = this.shopListIndex;
    dat.type = 'wishlist';
    dat.language_id = this.config.langId;
    dat.currency_code = this.config.currecnyCode;
    await this.config.postHttp('getallproducts', dat).then(async (data: any) => {
      this.httpRunning = false;
      if (data.success == 1) {
        this.shopListIndex++;
        var prod = data.product_data;
        for (let value of prod) {
          this.shared.addToCart(value, []);
        }
        hasMoreProduct = true;
        return await hasMoreProduct;
      }
      if (data.success == 0) {
        hasMoreProduct = false;
        return await hasMoreProduct;
      }
    });
    return await hasMoreProduct;
  }
  stopInterval() {
    clearInterval(this.interval);
  }
  hideCartPopoup(e) {
    if (!e.target.classList.contains('cart-pop-up')) {
      this.shared.isCartPopUpOpen.next(false);
    } else {
      this.shared.isCartPopUpOpen.next(true);
    }
  }
  hideCartPopoupScroll(e) {
    if (!e.target.classList.contains('cart-pop-up')) {
      this.shared.isCartPopUpOpen.next(false);
    }
  }
}