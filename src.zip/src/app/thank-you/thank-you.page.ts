import { Component, OnInit } from '@angular/core';
import { NavController, Events } from '@ionic/angular';
import { SharedDataService } from 'src/providers/shared-data/shared-data.service';
import { ConfigService } from 'src/providers/config/config.service';
import { GoogleAnalytics } from '@ionic-native/google-analytics/ngx';

@Component({
  selector: 'app-thank-you',
  templateUrl: './thank-you.page.html',
  styleUrls: ['./thank-you.page.scss'],
})
export class ThankYouPage implements OnInit {
  constructor(
    public navCtrl: NavController,
    public shared: SharedDataService,
    public config: ConfigService,
    public events: Events,
    public ga: GoogleAnalytics
  ) {
  }
  openHome() {
    this.ga.trackEvent('AlışverişYapıldı', 'Teşekkürler Sayfası', 'Anasayfaya Dön');
    this.navCtrl.navigateRoot('app/home3');
    this.shared.onStart();
  }
  openOrders() {
    this.ga.trackEvent('AlışverişYapıldı', 'Teşekkürler Sayfası', 'Siparişlerime Dön');
    this.navCtrl.navigateRoot('/my-orders');
    this.shared.onStart();
  }
  ngOnInit() {
    this.ga.trackView('Sipariş Verildi. Teşekkürler Sayfası').then(() => {
    });
  }
}
