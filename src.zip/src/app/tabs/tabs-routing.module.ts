import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { TabsPage } from './tabs.page';

const routes: Routes = [
  {
    path: 'app',
    component: TabsPage,
    children:
      [
        {
            path: 'home',
            children:
              [
                {
                  path: '',
                  loadChildren: '../home-pages/home3/home3.module#Home3PageModule'
                }
              ]
          },
        {
          path: 'home3',
          children:
            [
              {
                path: '',
                loadChildren: '../home-pages/home3/home3.module#Home3PageModule'
              }
            ]
        },
          {
            path: 'products/:id/:name/:type',
            children:
              [
                {
                  path: '',
                  loadChildren: '../products/products.module#ProductsPageModule'
                }
              ]
          },
        {
          path: 'settings',
          children:
            [
              {
                path: '',
                loadChildren: '../settings/settings.module#SettingsPageModule'
              }
            ]
        },
        {
            path: 'search',
            children:
              [
                {
                  path: '',
                  loadChildren: '../search/search.module#SearchPageModule'
                }
              ]
          },
          {
            path: 'cart',
            children:
              [
                {
                  path: '',
                  loadChildren: '../cart/cart.module#CartPageModule'
                }
              ]
          },
          {
            path: 'order',
            children:
              [
                {
                  path: '',
                  loadChildren: '../order/order.module#OrderPageModule'
                }
              ]
          },
          {
            path: 'campaignes',
            children:
              [
                {
                  path: '',
                  loadChildren: '../campaignes/campaignes.module#CampaignesPageModule'
                }
              ]
          },
          {
            path: 'wish-list',
            children:
              [
                {
                  path: '',
                  loadChildren: '../wish-list/wish-list.module#WishListPageModule'
                }
              ]
          },
          {
            path: 'courier',
            children:
              [
                {
                  path: '',
                  loadChildren: '../courier/courier.module#CourierPageModule'
                }
              ]
          },
        {
          path: '',
          redirectTo: '/app/home3',
          pathMatch: 'full'
        }
      ]
  },
  {
    path: '',
    redirectTo: '/app/home3',
    pathMatch: 'full'
  }
];

@NgModule({
  imports:
    [
      RouterModule.forChild(routes)
    ],
  exports:
    [
      RouterModule
    ]
})
export class TabsPageRoutingModule {}