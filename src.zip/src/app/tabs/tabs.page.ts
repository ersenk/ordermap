import { Component, OnInit } from '@angular/core';
import { ConfigService } from 'src/providers/config/config.service';
import { Router } from '@angular/router';
import { SharedDataService } from '../../providers/shared-data/shared-data.service';

@Component({
  selector: 'app-tabs',
  templateUrl: './tabs.page.html',
  styleUrls: ['./tabs.page.scss'],
})
export class TabsPage implements OnInit {

  constructor(
    public config: ConfigService,
    public router: Router,
    public shared: SharedDataService
  ) { }
  selectedTab = null;
  ngOnInit() {
  }
  tabsChanged() {
    const url = this.router.url;
    if (url.includes('order')) {
      this.selectedTab = 'cart';
    } else if(url.includes('categories')) {
      this.selectedTab = 'categories';
    } else {
      this.selectedTab = null;
    }
  }
}
