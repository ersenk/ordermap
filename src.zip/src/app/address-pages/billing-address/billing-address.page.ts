import { Component, OnInit } from '@angular/core';
import { ModalController } from '@ionic/angular';
import { SharedDataService } from 'src/providers/shared-data/shared-data.service';

@Component({
  selector: 'app-billing-address',
  templateUrl: './billing-address.page.html',
  styleUrls: ['./billing-address.page.scss'],
})
export class BillingAddressPage implements OnInit {

  constructor(
    private modalController: ModalController,
    public shared: SharedDataService
  ) { }
  shippingData = {
    name: '',
    tax_number: '',
    taxt_city: '',
    open_address: '',
  }

  ngOnInit() {

  }
  dismiss() {
    this.modalController.dismiss();
  }

  saveBillingAddress() {
    this.dismiss();
    this.shared.toast('Fatura adresiniz eklendi');
  }
}
