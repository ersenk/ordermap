import { Component, OnInit } from '@angular/core';


import { ConfigService } from 'src/providers/config/config.service';
import { SharedDataService } from 'src/providers/shared-data/shared-data.service';
import { ModalController, NavController } from '@ionic/angular';
import { HttpClient } from '@angular/common/http';
import { LoadingService } from 'src/providers/loading/loading.service';
import { UserAddressService } from 'src/providers/user-address/user-address.service';
import { SelectCountryPage } from 'src/app/modals/select-country/select-country.page';
import { SelectZonesPage } from 'src/app/modals/select-zones/select-zones.page';
import { EditAddressPage } from 'src/app/modals/edit-address/edit-address.page';
import { GoogleAnalytics } from '@ionic-native/google-analytics/ngx';
@Component({
  selector: 'app-shipping-address',
  templateUrl: './shipping-address.page.html',
  styleUrls: ['./shipping-address.page.scss'],
})
export class ShippingAddressPage implements OnInit {
    customersAddresses=[];
  constructor(
    public navCtrl: NavController,
    public config: ConfigService,
    public http: HttpClient,
    public shared: SharedDataService,
    public modalCtrl: ModalController,
    public loading: LoadingService,
    public userAddress: UserAddressService,
    public ga: GoogleAnalytics
    ) {
    this.loading.show();

    var dat: { [k: string]: any } = {};
    dat.customers_id = this.shared.customerData.customers_id;
    this.config.postHttp('getalladdress', dat).then((data: any) => {
      this.loading.hide();
      if (data.success == 1) {
        this.customersAddresses = data.data;
      }
      if (data.success == 0) { 
        this.addShippingAddress();
      }
    });
    this.shared.orderDetails.delivery_contact_telephone = this.shared.customerData.customers_telephone;
  }

  radioGroupChange(event){
    this.customersAddresses.forEach(element => {
        if(element.id == event.detail.value){
          this.shared.orderDetails.delivery_address_id = element.id;
          this.shared.orderDetails.delivery_city_id = element.city_id;
          this.shared.orderDetails.delivery_city_name = element.city_name;
          this.shared.orderDetails.delivery_zone_id = element.zone_id;
          this.shared.orderDetails.delivery_zone_name = element.zone_name;
          this.shared.orderDetails.delivery_district_name = element.district_name;
          this.shared.orderDetails.delivery_street_name = element.street_name;
          this.shared.orderDetails.delivery_open_address = element.open_address;
          this.shared.orderDetails.delivery_contact_telephone = element.contact_phone;
        }
    });

  }
  submit() {
    this.navCtrl.navigateForward("delivery-hours");
  }
  async addShippingAddress() {
    let modal = await this.modalCtrl.create({
      component: EditAddressPage,
      componentProps: { type: 'add' }
    });
    modal.onDidDismiss().then(() => {
      this.getAllAddress();
    })
    return await modal.present();
  }
  getAllAddress() {
    this.loading.show();
    var dat = { customers_id: this.shared.customerData.customers_id };
    this.config.postHttp('getalladdress', dat).then((data: any) => {
      this.loading.hide();
      if (data.success == 1) {
        this.customersAddresses = data.data;
      }
    });
  }

  ngOnInit() {
    this.ga.trackView('Kayıtlı Adres Seç Sayfası').then(() => {
    });
  }


}
