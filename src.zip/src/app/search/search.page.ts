import { Component, OnInit, ApplicationRef } from '@angular/core';
import { LoadingService } from 'src/providers/loading/loading.service';
import { SharedDataService } from 'src/providers/shared-data/shared-data.service';

import { ConfigService } from 'src/providers/config/config.service';
import { NavController } from '@ionic/angular';
import { HttpClient } from '@angular/common/http';
import { GoogleAnalytics } from '@ionic-native/google-analytics/ngx';

@Component({
  selector: 'app-search',
  templateUrl: './search.page.html',
  styleUrls: ['./search.page.scss'],
})
export class SearchPage implements OnInit {
  search: any;
  products: any;
  showCategories = true;
  populerSearches = ['Eti' ,'Doğuş', 'coca cola','çikolata','çay','gofret','şeker','kahve'];
  constructor(
    public navCtrl: NavController,
    public config: ConfigService,
    public http: HttpClient,
    public loading: LoadingService,
    public shared: SharedDataService,
    public ga: GoogleAnalytics
    ) { }
  onChangeKeyword = function (e) {
    //console.log(this.search);
    // if (search != undefined) {
    //rchResult = [];
    //  }
  }
  getSearchData = function() {

    if (this.search != undefined) {
      if (this.search == null || this.search == '') {
        return 0;
      }
    }
    else {
      return 0;
    }
    this.loading.show();
    this.config.postHttp('getsearchdata', { 'searchValue': this.search, 'language_id': this.config.langId }).then((data: any) => {
      this.loading.hide();
      if (data.success == 1) {
        this.products = data.product_data.products;
        this.showCategories = false;
      }
      if (data.success == 0) {
        this.shared.toast(data.message);
      }
    });
  };



  openProducts(id, name) {
    this.navCtrl.navigateForward("/products/" + id + "/" + name + "/0");
  }

  ngOnInit() {
    this.ga.trackView('Ürün Arama Sayfası').then(() => {
    });
  }
  getPopularSearchWord(popular){
    this.search = popular;
  }

  hideCartPopoup(e) {
    if (!e.target.classList.contains('cart-pop-up')) {
      this.shared.isCartPopUpOpen.next(false);
    } else {
      this.shared.isCartPopUpOpen.next(true);
    }
  }
  hideCartPopoupScroll(e) {
    if (!e.target.classList.contains('cart-pop-up')) {
      this.shared.isCartPopUpOpen.next(false);
    }
  }

}
