import { Component, OnInit, ViewChild } from '@angular/core';
import { IonInfiniteScroll, IonContent, IonSlides, NavController, Events, ActionSheetController, MenuController } from '@ionic/angular';
import { ActivatedRoute } from '@angular/router';
import { ConfigService } from 'src/providers/config/config.service';
import { SharedDataService } from 'src/providers/shared-data/shared-data.service';
import { LoadingService } from 'src/providers/loading/loading.service';

@Component({
  selector: 'app-products',
  templateUrl: './products.page.html',
  styleUrls: ['./products.page.scss'],
})
export class ProductsPage implements OnInit {

  @ViewChild(IonContent, { static: false }) content: IonContent;
  @ViewChild('mainCategorySlide', { static: false }) slides: IonSlides;
  @ViewChild('subCategorySlide', { static: false }) subCategorySlide: IonSlides;
  scrollTopButton = false;
  products = new Array;
  selectedTab = '';
  currentSection = '';
  selectedCategory = '';
  selectedSubCategory = '';
  subCategories = [];
  subCategoriesPositionToTop = [];
  contents = [];
  categoryId = '';
  categoryName = '';
  sortOrder = 'Newest';
  sortArray = ['Newest', 'A - Z', 'Z - A', 'Price : high - low', 'Price : low - high', 'Top Seller', 'Special Products', 'Most Liked', 'Cancel'];
  page = 0;
  applyFilter = false;
  filters = [];
  selectedFilters = [];
  price = { lower: 0, upper: 500 };
  maxAmount = 500;
  side = "right";
  productView = 'grid';
  httpRunning = true;
  sliderConfig = {
    slidesPerView: "auto",
    center:false,
  }

  constructor(
    public navCtrl: NavController,
    private activatedRoute: ActivatedRoute,
    public config: ConfigService,
    public shared: SharedDataService,
    public loading: LoadingService,
    public events: Events,
    public actionSheet: ActionSheetController,
    public menuCtrl: MenuController
  ) {
    if (shared.dir == "rtl") { this.side = "left"; }

    if (this.activatedRoute.snapshot.paramMap.get('id') != undefined) { this.selectedCategory = this.selectedTab = this.categoryId = this.activatedRoute.snapshot.paramMap.get('id'); }
    if (this.activatedRoute.snapshot.paramMap.get('name') != undefined) { this.categoryName = this.activatedRoute.snapshot.paramMap.get('name'); }
    if (this.activatedRoute.snapshot.paramMap.get('type') != undefined) { this.sortOrder = this.activatedRoute.snapshot.paramMap.get('type'); }
    //  if (this.activatedRoute.snapshot.paramMap.get('slug') != undefined) this.sortOrder = this.activatedRoute.snapshot.paramMap.get('slug');
    if (parseInt(this.selectedTab) == 0) { this.selectedTab = ''; }
    this.getProducts();
    this.getFilters(this.categoryId);
  }

  getProducts() {
    this.httpRunning = true;
    this.contents = [];
    if (this.page == 0) { //this.loading.show(); 
    }
    var dat: { [k: string]: any } = {};
    if (this.shared.customerData != null) { //in case user is logged in customer id will be send to the server to get user liked products
      dat.customers_id = this.shared.customerData.customers_id;
    }
    if (this.applyFilter == true) {
      dat.filters = this.selectedFilters;
      dat.price = { minPrice: this.price.lower, maxPrice: this.price.upper };
    }
    dat.categories_id = this.selectedCategory;
    dat.page_number = this.page;
    dat.type = this.sortOrder;
    dat.language_id = this.config.langId;
    dat.currency_code = this.config.currecnyCode;
    dat.branch_id = this.shared.branchId;
    this.config.postHttp('getmyallproducts', dat).then((data: any) => {
      this.loading.hide();
      this.httpRunning = false;
      if (this.page == 0) { this.products = new Array; this.scrollToTop(); }
      if (data.success == 1) {
        this.page++;
        this.contents = data.data;
        setTimeout(() => {
          this.getCurrenctSubcategoryDiv();
        }, 300);
      } 
    }, (error: any) => {
      this.httpRunning = false;
    });
  }
  changeSubCategory(c) {
    if (c == '') {
      this.selectedCategory = c;
      this.selectedTab = c;
    } else {
      this.selectedCategory = c.id;
      this.selectedTab = c.id;
      let ind = 0;
      this.shared.categories.forEach((value, index) => {
          if (this.selectedCategory == value.id) { ind = index; }
        });
      this.slides.slideTo(ind, 1000, true);
    }
    this.subCategories = [];
    for (let index = 0; index < this.shared.subCategories.length; index++) {
      if (this.shared.subCategories[index].parent_id == c.id) {
        this.subCategories.push(this.shared.subCategories[index]);
      }
    }
    this.changeTab(this.subCategories[0]);
  }

  changeTab(c) {
    this.applyFilter = false;

    this.page = 0;
    if (c == '') { this.selectedTab = c }
    else { this.selectedTab = c.id;
    }
    this.getProducts();
    this.getFilters(this.selectedTab);
    this.getCurrenctSubcategoryDiv();
  }

  fillFilterArray(fValue, fName, keyword) {

    if (!fValue.target.checked == true) {
      this.selectedFilters.push({ 'name': fName, 'value': keyword });
    } else {
      this.selectedFilters.forEach((value, index) => {
        if (value.value == keyword) {
          this.selectedFilters.splice(index, 1);
        }
      });
    }
  }

  getFilters(id) {
    var dat: { [k: string]: any } = {};
    dat.categories_id = id;
    dat.language_id = this.config.langId;
    dat.currency_code = this.config.currecnyCode;
    this.config.postHttp('getfilters', dat).then((data: any) => {
      if (data.success == 1) {
        this.filters = data.filters;
      }
      this.maxAmount = this.price.upper = data.maxPrice;
    });
  }
  applyFilters() {
    this.applyFilter = true;

    this.page = 0;
    this.getProducts();
    this.menuCtrl.close("menu2");
  }
  resetFilters() {
    this.getFilters(this.selectedTab);
    this.menuCtrl.close("menu2");
  }
  removeFilters() {
    this.applyFilter = false;
    this.page = 0;
    this.getProducts();
    this.getFilters(this.selectedTab);
  }
  ngOnChanges() {

  }
  getSortProducts(value) {

    if (value == 'Newest') { value = 'newest'; }
    else if (value == 'A - Z') { value = 'a to z'; }
    else if (value == 'Z - A') { value = 'z to a'; }
    else if (value == 'Price : high - low') { value = 'high to low'; }
    else if (value == 'Price : low - high') { value = 'low to high'; }
    else if (value == 'Top Seller') { value = 'top seller'; }
    else if (value == 'Special Products') { value = 'special'; }
    else if (value == 'Most Liked') { value = 'most liked'; }
    else { value = value; }

    //console.log(value);
    if (value == this.sortOrder) { return 0; }
    else {
      this.sortOrder = value;
      this.page = 0;
      this.getProducts();
    }
  }

  async openSortBy() {
    var buttonArray = [];
    this.shared.translateArray(this.sortArray).then(async (res: any) => {
      for (let key in res) {
        if (key != 'Cancel') {
          buttonArray.push({ text: res[key], handler: () => { this.getSortProducts(key) } });
        } else {
          buttonArray.push(
            {
              text: res[key],
              role: 'cancel',
              handler: () => {
              }
            }
          );
        }
      }
      var action = await this.actionSheet.create({
        buttons: buttonArray
      });
      await action.present();
    });
  }

  changeLayout() {
    if (this.productView == 'list') { this.productView = "grid"; }
    else { this.productView = "list"; }

    this.scrollToTop();
  }
  scrollToSubCategoryDiv(i) {
    for (let index = 0; index < this.subCategoriesPositionToTop.length; index++) {
      if ( i == index) {
        this.content.scrollToPoint(0, this.subCategoriesPositionToTop[index].position, 300);
      }
    }
  }
  scrollToTop() {
    try {
      this.content.scrollToTop(700);
      this.scrollTopButton = false;
    } catch (error) {

    }
  }
  onScroll(e) {
    if (e.scrollTop >= 1200) { this.scrollTopButton = true; }
    if (e.scrollTop < 1200) { this.scrollTopButton = false; }
    var currentPositionOfPage = e.detail.scrollTop;
    for (let index = 0; index < this.subCategoriesPositionToTop.length; index++) {
      if (currentPositionOfPage >= this.subCategoriesPositionToTop[this.subCategoriesPositionToTop.length - 1].position) {
        this.subCategorySlideTo(index);
        this.selectedTab = this.subCategoriesPositionToTop[index].id;
      }
      if (currentPositionOfPage < this.subCategoriesPositionToTop[this.subCategoriesPositionToTop.length - 1].position) {
        if (currentPositionOfPage >= parseInt(this.subCategoriesPositionToTop[index].position) && currentPositionOfPage < parseInt(this.subCategoriesPositionToTop[index + 1].position)) {
          this.subCategorySlideTo(index);
          this.selectedTab = this.subCategoriesPositionToTop[index].id;
        }
      }
    }
  }

  ionViewDidEnter() {
    try {
      setTimeout(() => {
        let ind = 0;
        this.shared.categories.forEach((value, index) => {
          if (this.selectedCategory == value.id) { ind = index; }
        });
        this.slides.slideTo(ind, 1000, true);
        console.log('active main cat slide: ' + this.slides.getActiveIndex());
      }, 500);
    } catch (error) {

    }
  }
  ngOnInit() {
    setTimeout(() => {
      for (let value of this.shared.categories) {
        if (value.id == this.categoryId) {
          this.changeSubCategory(value);
        }
      }
    }, 500);
  }
  getCurrenctSubcategoryDiv() {
    this.subCategoriesPositionToTop = [];
    for (let index = 0; index < this.subCategories.length; index++) {
      const myDiv = document.getElementById(this.subCategories[index].id);
      const value = { position: myDiv.offsetTop, id: this.subCategories[index].id };
      this.subCategoriesPositionToTop.push(value);
    }
  }
  subCategorySlideTo(index) {
    this.subCategorySlide.slideTo(index, 500);
  }
  mainCategorySlideTo(index) {
    this.slides.slideTo(index,300);
  }
  hideCartPopoup(e) {
    if (!e.target.classList.contains('cart-pop-up')) {
      this.shared.isCartPopUpOpen.next(false);
    } else {
      this.shared.isCartPopUpOpen.next(true);
    }
  }
  hideCartPopoupScroll(e) {
    if (!e.target.classList.contains('cart-pop-up')) {
      this.shared.isCartPopUpOpen.next(false);
    }
  }
  contentResized(){
    console.log('content resized');
  }
}