import { Component, OnInit } from '@angular/core';
import { ModalController } from '@ionic/angular';
import { SharedDataService } from 'src/providers/shared-data/shared-data.service';

@Component({
  selector: 'app-mesafeli-satis-sozlesmesi',
  templateUrl: './mesafeli-satis-sozlesmesi.page.html',
  styleUrls: ['./mesafeli-satis-sozlesmesi.page.scss'],
})
export class MesafeliSatisSozlesmesiPage implements OnInit {

  constructor(
    public mdCtrl: ModalController,
    public shared: SharedDataService
  ) {
    this.shared.currentOpenedModel = this;
  }

  ngOnInit() {
  }

  dismiss() {
    this.shared.currentOpenedModel = null;
    this.mdCtrl.dismiss();
  }

}
