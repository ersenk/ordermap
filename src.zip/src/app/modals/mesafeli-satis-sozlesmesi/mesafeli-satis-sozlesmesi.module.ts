import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';

import { IonicModule } from '@ionic/angular';

import { MesafeliSatisSozlesmesiPage } from './mesafeli-satis-sozlesmesi.page';

const routes: Routes = [
  {
    path: '',
    component: MesafeliSatisSozlesmesiPage
  }
];

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    RouterModule.forChild(routes)
  ],
  declarations: [MesafeliSatisSozlesmesiPage]
})
export class MesafeliSatisSozlesmesiPageModule {}
