import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BilgilendirmeFormuPage } from './bilgilendirme-formu.page';

describe('BilgilendirmeFormuPage', () => {
  let component: BilgilendirmeFormuPage;
  let fixture: ComponentFixture<BilgilendirmeFormuPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BilgilendirmeFormuPage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BilgilendirmeFormuPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
