import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ConfigService } from 'src/providers/config/config.service';
import { ModalController } from '@ionic/angular';
import { LoadingService } from 'src/providers/loading/loading.service';
import { SharedDataService } from 'src/providers/shared-data/shared-data.service';
import { TermServicesPage } from '../term-services/term-services.page';
import { RefundPolicyPage } from '../refund-policy/refund-policy.page';
import { PrivacyPolicyPage } from '../privacy-policy/privacy-policy.page';
import { OtpPagePage } from '../otp-page/otp-page.page';
import { GoogleAnalytics } from '@ionic-native/google-analytics/ngx';

@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.page.html',
  styleUrls: ['./sign-up.page.scss'],
})
export class SignUpPage implements OnInit {
  formData = {
    customers_firstname: '',
    customers_lastname: '',
    customers_telephone: '',
    otp_id:'',
    otp:'',
  };
  values: any = [];
  image = "";
  errorMessage = '';
  consumerKeyEncript: any;
  consumerSecretEncript: any;
  submitButtonActive: boolean = false;
  constructor(
    public http: HttpClient,
    public config: ConfigService,
    public modalCtrl: ModalController,
    public loading: LoadingService,
    public shared: SharedDataService,
    public ga: GoogleAnalytics

  ) {
    this.shared.currentOpenedModel = this;
  }
  registerOtp() {
    this.errorMessage = '';
    this.loading.show();
    this.config.postHttp('registerattempt', this.formData).then((data: any) => {
      this.loading.hide();
      if (data.success == 1) {
        this.formData.otp_id = data.data.otp_id;
        this.openOtpPage();
        this.dismiss();
      }
      if (data.success == 0) {
        this.shared.showAlert(data.message);
      }
    });
  }
  phoneNumberChanged(e) {
  }

 async openOtpPage() {
  let modal = await this.modalCtrl.create({
    component: OtpPagePage,
    componentProps: {
      goal: 'register',
      registerCustomerData: this.formData
    }
  });
  return await modal.present();
}
  async  openPrivacyPolicyPage() {
    let modal = await this.modalCtrl.create({
      component: PrivacyPolicyPage
    });
    return await modal.present();
  }
  async  openTermServicesPage() {
    let modal = await this.modalCtrl.create({
      component: TermServicesPage
    });
    return await modal.present();
  }
  async  openRefundPolicyPage() {
    let modal = await this.modalCtrl.create({
      component: RefundPolicyPage
    });
    return await modal.present();
  }
  async dismiss() {
    this.modalCtrl.dismiss();
  }

  ngOnInit() {
    this.ga.trackView('Kayıt Ol Sayfası').then(() => {
    });
  }

}
