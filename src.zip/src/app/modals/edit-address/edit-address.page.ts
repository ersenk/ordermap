import { Component, OnInit } from '@angular/core';
import { Events, ModalController, NavParams } from '@ionic/angular';
import { ConfigService } from 'src/providers/config/config.service';
import { LoadingService } from 'src/providers/loading/loading.service';
import { SharedDataService } from 'src/providers/shared-data/shared-data.service';
import { SelectZonesPage } from '../select-zones/select-zones.page';
import { SelectCountryPage } from '../select-country/select-country.page';
import { Geolocation } from '@ionic-native/geolocation/ngx';
import {
  GoogleMaps,
  GoogleMap,
  GoogleMapsEvent,
  GoogleMapOptions,
  CameraPosition,
  MarkerOptions,
  Marker,
  Environment,
  ILatLng
} from '@ionic-native/google-maps';
import { Diagnostic } from '@ionic-native/diagnostic/ngx';
import { LocationAccuracy } from '@ionic-native/location-accuracy/ngx';

declare var google: any;
@Component({
  selector: 'app-edit-address',
  templateUrl: './edit-address.page.html',
  styleUrls: ['./edit-address.page.scss'],
})
export class EditAddressPage implements OnInit {
  private map: GoogleMap;
  shippingData: { [k: string]: any } = {};
  data;
  type = 'update';
  lat;
  lng;
  canSubmitForm: boolean = false;
  originMarker: Marker;
  constructor(
    public events: Events,
    public config: ConfigService,
    public modalCtrl: ModalController,
    public loading: LoadingService,
    public shared: SharedDataService,
    public navParams: NavParams,
    public geoLocation: Geolocation,
    private diagnostic: Diagnostic,
    private locationAccuracy: LocationAccuracy,
  ) {
    this.data = navParams.get('data');
    this.type = navParams.get('type');
    if (this.type != 'add') {
      this.shippingData.address_id = this.data.address_id;
      this.shippingData.address_name = this.data.address_name;
      this.shippingData.district_name = this.data.district_name;
      this.shippingData.street_name = this.data.street_name;
      this.shippingData.open_address = this.data.open_address;
      this.shippingData.city_id = this.data.city_id;
      this.shippingData.city_name = this.data.city_name;
      this.shippingData.zone_id = this.data.zone_id;
      this.shippingData.zone_name = this.data.zone_name;
      this.shippingData.contact_phone = this.data.contact_phone;
      this.shippingData.suburb = this.data.suburb;
      this.shippingData.is_default = this.data.is_default == 1 ? true : false;
      this.shippingData.lat = this.lat;
      this.shippingData.lng = this.lng;
    }
  }
  ionViewWillEnter() {

  }
  ionViewDidEnter() {
    //  this.getMyLocation();
    this.shared.isLocationTurnedOn.subscribe((open) => {
      if (open) {
        console.log('edit address location turned on! ');
        this.canSubmitForm = true;
        this.getMyLocation();
      } else {
        console.log('edit address location off! ');
        this.canSubmitForm = false;
      }
    }, error => {
    });
  }
  ngOnInit() {
    this.shippingData.is_default = 0;
    if (this.type == 'add') {
      this.getDefaultCity();
      this.shippingData.is_default = true;
    } else {
      this.shippingData.is_default = this.data.is_default == 1 ? true : false;
    }
  }
  async selectCityPage() {
    let modal = await this.modalCtrl.create({
      component: SelectCountryPage,
      componentProps: { page: 'editShipping' }
    });
    modal.onDidDismiss().then(() => {
      this.updateCityZone();
      this.getdefaultZone(this.shippingData.city_id);
    })
    return await modal.present();
  }
  async selectZonePage() {
    let modal = await this.modalCtrl.create({
      component: SelectZonesPage,
      componentProps: { page: 'editShipping', id: this.shippingData.city_id }
    });
    modal.onDidDismiss().then(() => {
      this.updateCityZone();
    })
    return await modal.present();
  }
  dismiss() {
    this.modalCtrl.dismiss();
  }

  addShippingAddress = function (form) {
    this.loading.show();
    this.shippingData.customers_id = this.shared.customerData.customers_id;
    var dat = this.shippingData;
    console.log('shipping data' + JSON.stringify(dat));
    this.config.postHttp('addshippingaddress', dat).then((data: any) => {
      this.loading.hide();
      this.dismiss();
      this.shared.toast(data.message);
    }, function (response) {
      this.loading.hide();
    });
  };

  updateShippingAddress = function (form, id) {
    this.loading.show();
    this.shippingData.customers_id = this.shared.customerData.customers_id;
    this.shippingData.id = this.data.id;
    var dat = this.shippingData;
    this.config.postHttp('updateshippingaddress', dat).then((data: any) => {
      this.loading.hide();
      if (data.success == 1) {
        this.dismiss();
        this.shared.toast(data.message);
      }
    }, function (response) {
      this.loading.hide();
    });
  };

  updateCityZone() {
    if (this.shared.tempdata.city_id != undefined) {
      this.shippingData.city_id = this.shared.tempdata.city_id;
      this.shippingData.city_name = this.shared.tempdata.city_name;
      this.shippingData.zone_name = this.shared.tempdata.zone_name;
    }
    if (this.shared.tempdata.zone_name != undefined) {
      this.shippingData.zone_name = this.shared.tempdata.zone_name;
      this.shippingData.zone_id = this.shared.tempdata.zone_id;
    }
  }
  updateDefaultCheckbox(e) {
    if (this.shippingData.is_default == false) {
      this.shippingData.is_default = 0;
    } else {
      this.shippingData.is_default = 1
    }
  }
  async getDefaultCity() {
    this.config.postHttp('getcities', {}).then((data: any) => {
      this.loading.hide();
      if (data.success == 1) {
        data.data.forEach(element => {
          if (element.is_default == 1) {
            this.shippingData.city_name = element.city_name;
            this.shippingData.city_id = element.city_id;
            this.getdefaultZone(this.shippingData.city_id);
          }
        });
      }
    }, function (response) {
      this.loading.hide();
      console.log(response);
    });
  }
  async getdefaultZone(city_id) {
    const data = { city_id: city_id };
    this.config.postHttp('getzonesofcities', data).then((data: any) => {
      this.loading.hide();
      if (data.success == 1) {
        this.shippingData.zone_id = data.data[0].zone_id;
        this.shippingData.zone_name = data.data[0].zone_name;
      }
    }, function (response) {
      this.loading.hide();
    });
  }

  async getMyLocation() {

    await this.geoLocation.getCurrentPosition({
      maximumAge: 1000, timeout: 5000,
      enableHighAccuracy: true
    }).then((response) => {
      this.lat = response.coords.latitude;
      this.lng = response.coords.longitude;
      this.shippingData.lat = response.coords.latitude;
      this.shippingData.lng = response.coords.longitude;
      this.loadMap(this.lat, this.lng);
    }).catch((error) => {
      this.shared.toast('Oups bir hata oluştu');
    });
  }

  loadMap(lat, lng) {
    console.log('load map lat lng: ' + lat + ' ' + lng);
    Environment.setEnv({
      'API_KEY_FOR_BROWSER_RELEASE': 'AIzaSyBdqJY4fhuU-6GYqU00yjPlxZqIhROb7Qk',
      'API_KEY_FOR_BROWSER_DEBUG': 'AIzaSyBdqJY4fhuU-6GYqU00yjPlxZqIhROb7Qk'
    });
    const mapOptions: GoogleMapOptions = {
      camera: {
        target: {
          lat: lat,
          lng: lng
        },
        zoom: 16,
        tilt: 30
      }
    };
    this.map = GoogleMaps.create('map_canvas', mapOptions);
    this.originMarker = this.map.addMarkerSync({
      icon: 'red',
      animation: 'DROP',
      position: {
        lat: lat,
        lng: lng
      }
    });
  }

}
