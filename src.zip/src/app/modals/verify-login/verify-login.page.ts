import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-verify-login',
  templateUrl: './verify-login.page.html',
  styleUrls: ['./verify-login.page.scss'],
})
export class VerifyLoginPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
