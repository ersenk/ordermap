import { Component, OnInit, ApplicationRef} from '@angular/core';
import { ConfigService } from 'src/providers/config/config.service';
import { ModalController, NavController, Events, NavParams } from '@ionic/angular';
import { SharedDataService } from 'src/providers/shared-data/shared-data.service';
import { SignUpPage } from '../sign-up/sign-up.page';
import { LoadingService } from 'src/providers/loading/loading.service';
import { OtpPagePage } from '../otp-page/otp-page.page';
import { GoogleAnalytics } from '@ionic-native/google-analytics/ngx';
@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {
  values: any = [];
  formData = { phone: '', otp: '' };
  errorMessage = '';
  submitButtonActive = false;
  constructor(
    public config: ConfigService,
    public modalCtrl: ModalController,
    public loading: LoadingService,
    public shared: SharedDataService,
    public navCtrl: NavController,
    public events: Events,
    public navParams: NavParams,
    public ga: GoogleAnalytics
  ) {
    this.shared.currentOpenedModel = this;
  }

  loginAttempt() {
    this.loading.show();
    this.errorMessage = '';
    this.config.postHttp('loginattempt', this.formData).then((data: any) => {
      this.loading.hide();
      if (data.success == 1) {
       this.openOtpPage();
       this.dismiss();
      }
      if (data.success == 0) {
      this.shared.showAlert(data.message);
      }
    });
  }
  async openOtpPage() {
    const modal = await this.modalCtrl.create({
      component: OtpPagePage,
      componentProps: {
        goal: 'login',
        phone: this.formData.phone
      }
    });
    return await modal.present();
  }
  async openSignUpPage() {
    this.dismiss();
    const modal = await this.modalCtrl.create({
      component: SignUpPage
    });
    return await modal.present();
  }
  dismiss() {
    this.modalCtrl.dismiss();
  }
  ngOnInit() {
    this.ga.trackView('Giriş Sayfası').then(() => {
    });
  }

}
