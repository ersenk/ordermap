import { Component, OnInit } from '@angular/core';
import { ModalController } from '@ionic/angular';
import { LoadingService } from 'src/providers/loading/loading.service';
import { ConfigService } from 'src/providers/config/config.service';
import { SharedDataService } from 'src/providers/shared-data/shared-data.service';

@Component({
  selector: 'app-otp-page',
  templateUrl: './otp-page.page.html',
  styleUrls: ['./otp-page.page.scss'],
})
export class OtpPagePage implements OnInit {

  constructor(
    public modalCtrl: ModalController,
    public loading: LoadingService,
    public config: ConfigService,
    public shared: SharedDataService,
  ) { }
  errorMessage;
  otp;
  submitButtonActive: boolean = false;
  goal;
  phone;
  registerCustomerData;
  otp_id;
  ngOnInit() {
  }
  submitOtp(){
    if (this.goal == 'login'){
      this.login();
    }
    if (this.goal == 'register'){
      this.registerCustomer();
    }
  }

  login() {
    this.loading.show();
    this.errorMessage = '';
    const data = {phone: this.phone, otp: this.otp}
    this.config.postHttp('processlogin', data).then((data: any) => {
      this.loading.hide();
      if (data.success == 1) {
        this.shared.login(data.data[0]);
        this.dismiss();
      }
      if (data.success == 0) {
        this.shared.showAlert(data.message);
      }
    });
  }

  resendLoginOtp() {
    this.loading.show();
    this.errorMessage = '';
    const data = {phone: this.phone, otp: this.otp}
    this.config.postHttp('loginattempt', data).then((data: any) => {
      this.loading.hide();
      if (data.success == 0) {
        this.errorMessage = data.message;
      }
    });
  }

  registerCustomer() {
    this.errorMessage = '';
    this.loading.show();
    this.registerCustomerData.otp = this.otp;
    this.config.postHttp('processregistration', this.registerCustomerData).then((data: any) => {
      console.log('register response: '+JSON.stringify(data));
      this.loading.hide();
      if (data.success == 1) {
        this.shared.login(data.data[0]);
        this.dismiss();
      }
      if (data.success == 0) {
        this.shared.showAlert(data.message);
      }
    });
  }

  otpChanges(e){
    if (e.target.value.length == 6){
      this.submitButtonActive = true;
      this.submitOtp();
    } else {
      this.submitButtonActive = false;
    }
  }
  dismiss() {
    this.modalCtrl.dismiss();
  }
}
