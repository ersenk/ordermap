import { Component, OnInit, ViewChild } from '@angular/core';
import { ConfigService } from 'src/providers/config/config.service';
import { ModalController, Events, IonSearchbar, NavParams } from '@ionic/angular';
import { SharedDataService } from 'src/providers/shared-data/shared-data.service';
import { HttpClient } from '@angular/common/http';
import { LoadingService } from 'src/providers/loading/loading.service';

@Component({
  selector: 'app-select-country',
  templateUrl: './select-country.page.html',
  styleUrls: ['./select-country.page.scss'],
})
export class SelectCountryPage implements OnInit {
  @ViewChild('Searchbar', { static: false }) searchBar: IonSearchbar;

  searchQuery: string = '';
  items;
  countries = new Array;
  cities = new Array;
  constructor(
    public http: HttpClient,
    public events: Events,
    public config: ConfigService,
    public modalCtrl: ModalController,
    public loading: LoadingService,
    public shared: SharedDataService,
    public navParams: NavParams, ) {

    this.shared.currentOpenedModel = this;

    loading.show();
    var dat = { type: 'null' };
    config.postHttp('getcities', dat).then((data: any) => {
      loading.hide();
      this.items = this.cities = data.data
    });
  }

  initializeItems() {
    this.items = this.cities
  }

  getItems(ev: any) {
    // Reset items back to all of the items
    this.initializeItems();

    // set val to the value of the searchbar
    let val = ev.target.value;

    // if the value is an empty string don't filter the items
    if (val && val.trim() != '') {
      this.items = this.items.filter((item) => {
        return (item.city_name.toLowerCase().indexOf(val.toLowerCase()) > -1);
      })
    }
  }
  //close modal
  dismiss() {
    this.modalCtrl.dismiss();
    this.shared.currentOpenedModel = null;
  }
  selectCity(c) {
    if (this.navParams.get('page') == 'shipping') {
      console.log('city info: '+JSON.stringify(c));
      this.shared.orderDetails.delivery_city_name = c.city_name;
      this.shared.orderDetails.delivery_city_id   = c.city_id
      this.shared.orderDetails.delivery_zone_name = null;
      this.shared.orderDetails.delivery_zone_id = null;
    }
    else if (this.navParams.get('page') == 'editShipping') {
      console.log('city info: '+JSON.stringify(c));
      this.shared.tempdata.city_id   = c.city_id;
      this.shared.tempdata.city_name = c.city_name;
      this.shared.tempdata.zone_name = null;
      this.shared.tempdata.zone_id = null;
    }
    this.dismiss();
    console.log(this.navParams.get('page'));
  }

  ngOnInit() {
  }

}
