import { Pipe, PipeTransform } from '@angular/core';
import * as $ from 'jquery';
@Pipe({
  name: 'curency'
})
export class CurencyPipe implements PipeTransform {

  constructor() {
  }

  transform(value) {
    const currency = localStorage.currency;
    const decimals = localStorage.decimals;
    var priceFixed = parseFloat(value).toFixed(decimals);
    if (priceFixed.toString() == 'NaN') {
      return value + ' ' + currency;
    }
    else {
      return priceFixed + '' + currency;
    }
  }

}
