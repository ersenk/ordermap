import { TranslateAppPipe } from './translate-app.pipe';

describe('TranslateAppPipe', () => {
  it('create an instance', () => {
    const pipe = new TranslateAppPipe();
    expect(pipe).toBeTruthy();
  });
});
